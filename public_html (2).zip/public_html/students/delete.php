<?php

$student_id=$_GET['i'];

$book_id=$_GET['bi'];


$con=mysqli_connect("localhost","nurmoham_mad","@Nurmohammad1145","nurmoham_mad");

 
    $sql="DELETE FROM Students WHERE student_id=$student_id AND book_ID=$book_id";

    if(mysqli_query($con,$sql)){
    //      $sql2= "UPDATE Books SET Quantity = Quantity + 1 WHERE ID = '$book_id'";
    // if(mysqli_query($con,$sql2)){
    // echo "Quantity updated Successfully!";
    // }
    // else echo "Cannot update Quantity";
     echo "Deleted Successfully";
    }
    else echo "Cannot Delete";

    
    $sql1="SELECT Quantity FROM Books WHERE ID =$book_id";
    $result = mysqli_query($con, $sql1);






   
 

    



?>