<?php
header('Content-Type: application/json');
$student_id = "";
$student_name = "";
$student_id = $_GET['i'];
$student_name = $_GET['n'];



$con = mysqli_connect("localhost", "nurmoham_mad", "@Nurmohammad1145", "nurmoham_mad");

if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}

// Build the query safely
$sql = "SELECT * FROM `Students` WHERE 
    student_id LIKE '%$student_id%' AND 
    student_name LIKE '%$student_name%' ";

$result = mysqli_query($con, $sql);

$data = array();

if ($result) {
    foreach ($result as $row) {
        $userinfo['student_id'] = $row['student_id'];
        $userinfo['student_name'] = $row['student_name'];
        $userinfo['book_ID'] = $row['book_ID'];
        $userinfo['book_name'] = $row['book_name'];
       

        array_push($data, $userinfo);
    }
} else {
    echo "Error in SQL: " . mysqli_error($con);
    exit;
}

echo json_encode($data);
?>
