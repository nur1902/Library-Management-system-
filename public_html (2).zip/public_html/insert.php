<?php
$link = $_GET['i'];
$name = $_GET['n'];
$mobile = $_GET['m'];  
$email = $_GET['e'];
$quantity=$_GET['q'];




$con = mysqli_connect("localhost", "nurmoham_mad", "@Nurmohammad1145", "nurmoham_mad");

if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}

$sql = "INSERT INTO `Books` (link, name, author, catagory,Quantity) VALUES ('$link', '$name', '$email', '$mobile','$quantity')";


if (mysqli_query($con, $sql)) {
    echo "Connected and inserted successfully.";
} else {
    echo "Error: " . mysqli_error($con);
}



?>
