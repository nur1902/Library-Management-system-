<?php
    header('Content-Type: application/json; charset=utf-8');
 $con=mysqli_connect("localhost","nurmoham_mad","@Nurmohammad1145","nurmoham_mad");
   
    $pars="SELECT * FROM Books";
    $result=mysqli_query($con,$pars);
    $data=array();
    
   
    foreach($result as $row){
          
    $userinfo['id']=$row['ID'];
    $userinfo['name']=$row['name'];
    $userinfo['email']=$row['author'];
    $userinfo['mobile']=$row['catagory'];
    $userinfo['link']=$row['link'];
    $userinfo['Quantity']=$row['Quantity'];

    array_push($data, $userinfo);
    
    }

    echo json_encode($data);
    
    
    
    
 
?>