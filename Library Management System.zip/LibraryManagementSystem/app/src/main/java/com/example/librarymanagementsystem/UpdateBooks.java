package com.example.librarymanagementsystem;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

public class UpdateBooks extends AppCompatActivity {
    EditText Author,Name, name,author,catagory,link,quantity;
    LinearLayout searching,updating;
    Button search,update;
    ListView list;
    HashMap<String, String> hashMap;
    ArrayList<HashMap<String, String>> arrayList=new ArrayList<>();





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.update_books);

        Name=findViewById(R.id.Name);
        Author=findViewById(R.id.Author);
        searching=findViewById(R.id.searching);
        updating=findViewById(R.id.updating);
        search=findViewById(R.id.search);
        name=findViewById(R.id.name);
        author=findViewById(R.id.author);
        catagory=findViewById(R.id.catagory);
        link=findViewById(R.id.link);
        quantity=findViewById(R.id.quantity);
        list=findViewById(R.id.list);
        update=findViewById(R.id.update);

        search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name1=Name.getText().toString();
                String author1=Author.getText().toString();
                String url="http://nurmohammad.fun/search.php?n="+name1+"&e="+author1;
                JsonArrayRequest jsonArrayRequest=new JsonArrayRequest(Request.Method.GET, url, null, new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        // Toast.makeText(SearchBooks.this, "few data found", Toast.LENGTH_SHORT).show();
                        for (int i = 0; i < response.length(); i++) {

                            try {
                                JSONObject jsonObject = response.getJSONObject(i);
                                String name=jsonObject.getString("name");
                                String id=jsonObject.getString("id");
                                String mobile=jsonObject.getString("mobile");
                                String author=jsonObject.getString("email");
                                String link=jsonObject.getString("link");
                                String quantity=jsonObject.getString("Quantity");
                                hashMap =new HashMap<>();
                                hashMap.put("id",id);
                                hashMap.put("name",name);
                                hashMap.put("mobile",mobile);
                                hashMap.put("email",author);
                                hashMap.put("link",link);
                                hashMap.put("quantity",quantity);
                                arrayList.add(hashMap);


                            } catch (JSONException e) {
                                throw new RuntimeException(e);
                            }
                        }
                        if(arrayList.size()>0){
                            UpdateBooks.myAdapter myAdapter =new UpdateBooks.myAdapter();
                            list.setAdapter(myAdapter);

                        }
                        else {
                            AlertDialog alert=new AlertDialog.Builder(UpdateBooks.this)
                                    .setTitle("Alert")
                                    .setMessage("NO data found").show();
                        }

                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                }

                );
                if(name1.length()>0 || author1.length()>0){
                    RequestQueue requestQueue= Volley.newRequestQueue(UpdateBooks.this);
                    requestQueue.add(jsonArrayRequest);
                }
                else new AlertDialog.Builder(UpdateBooks.this).setMessage("Enter book name and author name").show();


            }
        });




    }

    public  class  myAdapter extends BaseAdapter {


        @Override
        public int getCount() {
            return arrayList.size();
        }

        @Override
        public Object getItem(int position) {
            return null;
        }

        @Override
        public long getItemId(int position) {
            return 0;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {


            LayoutInflater layoutInflater=getLayoutInflater();
            View myView=layoutInflater.inflate(R.layout.info,null);
            TextView name2 = myView.findViewById(R.id.name1);
            LinearLayout info=myView.findViewById(R.id.info);
            TextView id2 = myView.findViewById(R.id.id1);
            TextView author2 = myView.findViewById(R.id.author);
            TextView email2 = myView.findViewById(R.id.catagory);
            TextView quantity2=myView.findViewById(R.id.quantity);
            // Button update = myView.findViewById(R.id.update);
            // Button delete = myView.findViewById(R.id.delete);

            hashMap = arrayList.get(position);
            String name11 = hashMap.get("name");
            String id11 = hashMap.get("id");
            String author11 = hashMap.get("mobile");
            String email11 = hashMap.get("email");
            String link11=hashMap.get("link");
            String quantity11=hashMap.get("quantity");
            name2.setText("Name: "+name11);
            id2.setText("ID: "+id11);
            author2.setText("Catagory: "+author11);
            email2.setText("Writer: "+email11);
            quantity2.setText("Quantity :"+quantity11);

            info.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    searching.setVisibility(View.GONE);
                    updating.setVisibility(View.VISIBLE);
                    name.setText(name11);
                    author.setText(email11);
                    catagory.setText(author11);
                    link.setText(link11);
                    quantity.setText(quantity11);



                    update.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            String name1=name.getText().toString();
                            String author1=author.getText().toString();
                            String catagory1=catagory.getText().toString();
                            String link1=link.getText().toString();
                            String quantity1=quantity.getText().toString();
                            String url1="http://nurmohammad.fun/update.php?n="+name1+"&e="+author1+"&m="+catagory1+"&i="+id11+"&q="+quantity1+"&l="+link1;


                            StringRequest request2=new StringRequest(Request.Method.GET, url1, new Response.Listener<String>() {
                                @Override
                                public void onResponse(String response) {

                                     new AlertDialog.Builder(UpdateBooks.this).setMessage(response).setTitle("Server Response").show();



                                }
                            }, new Response.ErrorListener() {
                                @Override
                                public void onErrorResponse(VolleyError error) {
                                    new AlertDialog.Builder(UpdateBooks.this).setMessage(error.getMessage()).setTitle("Server Response").show();


                                }
                            });
                            if(author1.length()>0 && name1.length()>0 && catagory1.length()>0 && link1.length()>0&& quantity1.length()>0) {
                                RequestQueue requestQueue = Volley.newRequestQueue(UpdateBooks.this);
                                requestQueue.add(request2);
                            }
                            else {
                                new AlertDialog.Builder(UpdateBooks.this).setMessage("Fill All Fields.").setTitle("Server Response").show();

                            }




                        }
                    });



                }
            });





            return myView;
        }
    }


}
