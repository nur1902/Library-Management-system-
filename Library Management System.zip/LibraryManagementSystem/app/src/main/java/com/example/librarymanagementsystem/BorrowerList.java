package com.example.librarymanagementsystem;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.tabs.TabLayout;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

public class BorrowerList extends AppCompatActivity {

    ListView list;
    ProgressBar progressBar;

    HashMap<String, String> hashMap;
    ArrayList<HashMap<String, String>> arrayList=new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.borrower_list);

        progressBar=findViewById(R.id.progressbar1);


        list=findViewById(R.id.list);

        String url="http://nurmohammad.fun/students/getList.php";


        JsonArrayRequest jsonArrayRequest=new JsonArrayRequest(Request.Method.GET, url, null, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {

                progressBar.setVisibility(View.GONE);
                for(int i=0;i<response.length();i++){


                    try {
                        JSONObject jsonObject=response.getJSONObject(i);
                        hashMap=new HashMap<>();
                        String name1=jsonObject.getString("student_name");
                        String id1=jsonObject.getString("student_id");
                        String book_id=jsonObject.getString("book_id");
                        String book_name=jsonObject.getString("book_name");
                        hashMap.put("student_name",name1);
                        hashMap.put("student_id",id1);
                        hashMap.put("book_id",book_id);
                        hashMap.put("book_name",book_name);
                        arrayList.add(hashMap);



                    } catch (JSONException e) {
                        throw new RuntimeException(e);
                    }
                }
                if(arrayList.size()>0){
                    BorrowerList.myAdapter myAdapter =new BorrowerList.myAdapter();
                    list.setAdapter(myAdapter);

                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.d("serverRes",error.toString());
                android.app.AlertDialog alert=new AlertDialog.Builder(BorrowerList.this)
                        .setTitle("Alert")
                        .setMessage(error.getMessage()).show();

                // tv.setText(error.getMessage());
            }
        }
        );
        RequestQueue requestQueue= Volley.newRequestQueue(BorrowerList.this);
        requestQueue.add(jsonArrayRequest);


    }


    public class myAdapter extends BaseAdapter {

        @Override
        public int getCount() {
            return arrayList.size();
        }

        @Override
        public Object getItem(int position) {
            return null;
        }

        @Override
        public long getItemId(int position) {
            return 0;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {


            LayoutInflater layoutInflater = getLayoutInflater();
            View myView = layoutInflater.inflate(R.layout.stinfo, null);
            LinearLayout stinfo=myView.findViewById(R.id.stinfo);

            TextView name=myView.findViewById(R.id.student_name);
            TextView id=myView.findViewById(R.id.student_id);
            TextView book_name=myView.findViewById(R.id.book_name);
            TextView book_id=myView.findViewById(R.id.book_id);

            hashMap=arrayList.get(position);
            String name1=hashMap.get("student_name");
            String id1=hashMap.get("student_id");
            String book_id1=hashMap.get("book_id");
            String book_name1=hashMap.get("book_name");

            name.setText("Student Name: "+name1);
            id.setText("Student ID: "+id1);
            book_name.setText("Book Name: "+book_name1);
            book_id.setText("Book ID: "+book_id1);
            //link.setText(link11);




            //author.setText(author11);

            return  myView;



        }
    }
}