package com.example.librarymanagementsystem;

import android.app.AlertDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

public class AddBooks extends AppCompatActivity {

    EditText name,author,catagory,link,quantity;
    Button upload;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.add_books);



        name=findViewById(R.id.name);
        author=findViewById(R.id.author);
        catagory=findViewById(R.id.catagory);
        link=findViewById(R.id.link);
        upload=findViewById(R.id.upload);
        quantity=findViewById(R.id.quantity);



        upload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name1=name.getText().toString();
                String author1=author.getText().toString();
                String catagory1=catagory.getText().toString();
                String link1=link.getText().toString();
                String quantity1=quantity.getText().toString();
                String url="http://nurmohammad.fun/insert.php?n="+name1+"&e="+author1+"&m="+catagory1+"&i="+link1+"&q="+quantity1;


                StringRequest request2=new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        if(response.equals("Error: Duplicate entry '' for key 'Books.unique_name_author'")){
                            new AlertDialog.Builder(AddBooks.this).setMessage("This Book Already Exist.").setTitle("Server Response").show();
                        }
                        else new AlertDialog.Builder(AddBooks.this).setMessage(response).setTitle("Server Response").show();



                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                });
                 if(author1.length()>0 && name1.length()>0 && catagory1.length()>0 && link1.length()>0&& quantity1.length()>0) {
                     RequestQueue requestQueue = Volley.newRequestQueue(AddBooks.this);
                     requestQueue.add(request2);
                 }
                 else {
                     new AlertDialog.Builder(AddBooks.this).setMessage("Fill All Fields.").setTitle("Server Response").show();

                 }

            }
        });








    }
}