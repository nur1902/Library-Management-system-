package com.example.librarymanagementsystem;

import static android.view.View.VISIBLE;

import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class PdfReader extends AppCompatActivity {

    WebView tv;
    TextView display;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_pdf_reader1);
        tv=findViewById(R.id.tv);
        display=findViewById(R.id.display);
        String receivedUsername = getIntent().getStringExtra("link");
        if (receivedUsername.length()<=0){
            display.setVisibility(VISIBLE);
            display.setText("Pdf Not found");
        }
        else {


            tv.getSettings().setJavaScriptEnabled(true);
            WebSettings webSettings = tv.getSettings();
            webSettings.setJavaScriptEnabled(true); // Allow JavaScript
            webSettings.setDomStorageEnabled(true); // For HTML5 support
            webSettings.setLoadsImagesAutomatically(true);
            webSettings.setUseWideViewPort(true);
            webSettings.setLoadWithOverviewMode(true);
            webSettings.setBuiltInZoomControls(true);
            webSettings.setDisplayZoomControls(false);

            // Allow file access
            webSettings.setAllowFileAccess(true);
            webSettings.setAllowContentAccess(true);

            // Enable geolocation or database if needed
            webSettings.setDatabaseEnabled(true);
            webSettings.setGeolocationEnabled(true);

            // Handle all links inside the app
            tv.setWebViewClient(new WebViewClient());

            // For JavaScript alerts, uploads, etc.
            tv.setWebChromeClient(new WebChromeClient());

            // Load your desired website
            tv.loadUrl(receivedUsername);
        }




    }
    @Override
    public void onBackPressed() {
        if (tv.canGoBack()) {
            tv.goBack();
        } else {
            super.onBackPressed();
        }
    }
}