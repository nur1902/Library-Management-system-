package com.example.librarymanagementsystem;

import android.app.AlertDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

public class BorrowBooks extends AppCompatActivity {
    EditText Author,Name, name,Stdid,catagory,link,quantity;
    LinearLayout searching,borrowing;
    Button search,borrow;
    ListView list;
    HashMap<String, String> hashMap;
    ArrayList<HashMap<String, String>> arrayList=new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.borrow_books);
        Name=findViewById(R.id.Name);
        Author=findViewById(R.id.Author);
        searching=findViewById(R.id.searching);
        borrowing=findViewById(R.id.borrowing);
        search=findViewById(R.id.search);
        name=findViewById(R.id.name);
        Stdid=findViewById(R.id.Stdid);



        list=findViewById(R.id.list);
        borrow=findViewById(R.id.borrow);
        search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name1=Name.getText().toString();
                String author1=Author.getText().toString();
                String url="http://nurmohammad.fun/search.php?n="+name1+"&e="+author1;
                JsonArrayRequest jsonArrayRequest=new JsonArrayRequest(Request.Method.GET, url, null, new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        // Toast.makeText(SearchBooks.this, "few data found", Toast.LENGTH_SHORT).show();
                        for (int i = 0; i < response.length(); i++) {

                            try {
                                JSONObject jsonObject = response.getJSONObject(i);
                                String name=jsonObject.getString("name");
                                String id=jsonObject.getString("id");
                                String mobile=jsonObject.getString("mobile");
                                String author=jsonObject.getString("email");
                                String link=jsonObject.getString("link");
                                String quantity=jsonObject.getString("Quantity");
                                hashMap =new HashMap<>();
                                hashMap.put("id",id);
                                hashMap.put("name",name);
                                hashMap.put("mobile",mobile);
                                hashMap.put("email",author);
                                hashMap.put("link",link);
                                hashMap.put("quantity",quantity);
                                arrayList.add(hashMap);


                            } catch (JSONException e) {
                                throw new RuntimeException(e);
                            }
                        }
                        if(arrayList.size()>0){
                            BorrowBooks.myAdapter myAdapter =new BorrowBooks.myAdapter();
                            list.setAdapter(myAdapter);

                        }
                        else {
                            AlertDialog alert=new AlertDialog.Builder(BorrowBooks.this)
                                    .setTitle("Alert")
                                    .setMessage("NO data found").show();
                        }

                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                }

                );
                if(name1.length()>0 || author1.length()>0){
                    RequestQueue requestQueue= Volley.newRequestQueue(BorrowBooks.this);
                    requestQueue.add(jsonArrayRequest);
                }
                else new AlertDialog.Builder(BorrowBooks.this).setMessage("Enter book name and author name").show();


            }
        });




    }

    public  class  myAdapter extends BaseAdapter {


        @Override
        public int getCount() {
            return arrayList.size();
        }

        @Override
        public Object getItem(int position) {
            return null;
        }

        @Override
        public long getItemId(int position) {
            return 0;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {


            LayoutInflater layoutInflater=getLayoutInflater();
            View myView=layoutInflater.inflate(R.layout.info,null);
            TextView name2 = myView.findViewById(R.id.name1);
            LinearLayout info=myView.findViewById(R.id.info);
            TextView id2 = myView.findViewById(R.id.id1);
            TextView author2 = myView.findViewById(R.id.author);
            TextView email2 = myView.findViewById(R.id.catagory);
            TextView quantity2=myView.findViewById(R.id.quantity);
            // Button update = myView.findViewById(R.id.update);
            // Button delete = myView.findViewById(R.id.delete);

            hashMap = arrayList.get(position);
            String name11 = hashMap.get("name");
            String id11 = hashMap.get("id");
            String author11 = hashMap.get("mobile");
            String email11 = hashMap.get("email");
            String link11=hashMap.get("link");
            String quantity11=hashMap.get("quantity");
            name2.setText("Name: "+name11);
            id2.setText("ID: "+id11);
            author2.setText("Catagory: "+author11);
            email2.setText("Writer: "+email11);
            quantity2.setText("Quantity :"+quantity11);

            info.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    searching.setVisibility(View.GONE);
                    borrowing.setVisibility(View.VISIBLE);




                    borrow.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            int quantity22=Integer.valueOf(quantity11);
                            //int quantity2=quantity22-1;
                            //Toast.makeText(BorrowBooks.this, quantity2, Toast.LENGTH_LONG).show();


                            String url1="http://nurmohammad.fun/students/borrow.php?n="+name11+"&i="+id11+"&sid="+Stdid.getText().toString()+"&sn="+name.getText().toString()+"&q="+quantity11;


                            StringRequest request2=new StringRequest(Request.Method.GET, url1, new Response.Listener<String>() {
                                @Override
                                public void onResponse(String response) {

                                    new AlertDialog.Builder(BorrowBooks.this).setMessage(response).setTitle("Server Response").show();



                                }
                            }, new Response.ErrorListener() {
                                @Override
                                public void onErrorResponse(VolleyError error) {
                                    new AlertDialog.Builder(BorrowBooks.this).setMessage(error.getMessage()).setTitle("Server Response").show();


                                }
                            });
                            if(Stdid.getText().toString().length()>0 && name.getText().toString().length()>0) {
                                RequestQueue requestQueue = Volley.newRequestQueue(BorrowBooks.this);
                                requestQueue.add(request2);
                            }
                            else {
                                new AlertDialog.Builder(BorrowBooks.this).setMessage("Fill All Fields.").setTitle("Server Response").show();

                            }




                        }
                    });



                }
            });





            return myView;
        }
    }




}