package com.example.librarymanagementsystem;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

public class ReturnBooks extends AppCompatActivity {

    Button search;
    EditText stname,stid;
    ListView list;
    HashMap<String,String> hashMap;
    ArrayList<HashMap<String, String>> arrayList= new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.return_books);
        search=findViewById(R.id.search);
        stname=findViewById(R.id.stname);
        stid=findViewById(R.id.stid);
        list=findViewById(R.id.list);

        search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name=stname.getText().toString();
                String id=stid.getText().toString();
                String url="http://nurmohammad.fun/students/search.php?n="+name+"&i="+id;

                JsonArrayRequest jsonArrayRequest=new JsonArrayRequest(Request.Method.GET, url, null, new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {

                        for (int i = 0; i < response.length(); i++) {

                            try {
                                JSONObject jsonObject=response.getJSONObject(i);
                                hashMap=new HashMap<>();
                                String name1=jsonObject.getString("student_name");
                                String id1=jsonObject.getString("student_id");
                                String book_id=jsonObject.getString("book_ID");
                                String book_name=jsonObject.getString("book_name");
                                hashMap.put("student_name",name1);
                                hashMap.put("student_id",id1);
                                hashMap.put("book_id",book_id);
                                hashMap.put("book_name",book_name);
                                arrayList.add(hashMap);


                            } catch (JSONException e) {
                                throw new RuntimeException(e);
                            }

                            if (arrayList.size()>0){

                                myAdapter myAdapter=new myAdapter();
                                list.setAdapter(myAdapter);


                            }

                        }

                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        new AlertDialog.Builder(ReturnBooks.this)
                             .setTitle("Server Response")
                                .setMessage(error.getMessage()).show();
                    }
                }

                );
                if(name.length()>0 || id.length()>0){
                    RequestQueue requestQueue= Volley.newRequestQueue(ReturnBooks.this);
                    requestQueue.add(jsonArrayRequest);
                }
                else new AlertDialog.Builder(ReturnBooks.this).setMessage("Enter book name and author name").show();










            }
        });




    }

    public  class myAdapter extends BaseAdapter{

        @Override
        public int getCount() {
            return arrayList.size();
        }

        @Override
        public Object getItem(int position) {
            return null;
        }

        @Override
        public long getItemId(int position) {
            return 0;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {

            View myView=getLayoutInflater().inflate(R.layout.stinfo,null);

            LinearLayout stinfo=myView.findViewById(R.id.stinfo);

            TextView name=myView.findViewById(R.id.student_name);
            TextView id=myView.findViewById(R.id.student_id);
            TextView book_name=myView.findViewById(R.id.book_name);
            TextView book_id=myView.findViewById(R.id.book_id);

            hashMap=arrayList.get(position);
            String name1=hashMap.get("student_name");
            String id1=hashMap.get("student_id");
            String book_id1=hashMap.get("book_id");
            String book_name1=hashMap.get("book_name");

            name.setText("Student Name: "+name1);
            id.setText("Student ID: "+id1);
            book_name.setText("Book Name: "+book_name1);
            book_id.setText("Book ID: "+book_id1);


            stinfo.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    new AlertDialog.Builder(ReturnBooks.this)
                            .setTitle("Exit App")
                            .setMessage("Are you sure you want to Delete?")
                            .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    String url="http://nurmohammad.fun//students/delete.php?i="+id1+"&bi="+book_id1;
                                    StringRequest stringRequest= new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
                                        @Override
                                        public void onResponse(String response) {
                                            new AlertDialog.Builder(ReturnBooks.this).setTitle("Server Response").setMessage(response).show();

                                        }
                                    }, new Response.ErrorListener() {
                                        @Override
                                        public void onErrorResponse(VolleyError error) {
                                            new AlertDialog.Builder(ReturnBooks.this).setTitle("Server Response").setMessage(error.getMessage()).show();
                                        }
                                    }
                                    );
                                    RequestQueue requestQueue= Volley.newRequestQueue(ReturnBooks.this);
                                    requestQueue.add(stringRequest);


                                    Intent intent = getIntent();
                                    finish();
                                    startActivity(intent);
                                }
                            })
                            .setNegativeButton("No", null) // Dismisses the dialog
                            .show();


                }
            });




            return myView;
        }
    }
}