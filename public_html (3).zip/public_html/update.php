<?php
$id="";
$name="";
$m="";
$quantity="";
$email="";
$link="";
$id=$_GET['i'];
$name=$_GET['n'];
$m=$_GET["m"];
$email=$_GET['e'];
$quantity=$_GET['q'];
$link=$_GET['l'];

$con=mysqli_connect("localhost","nurmoham_mad","@Nurmohammad1145","nurmoham_mad");

 if(strlen($name) > 0){
    $sql="UPDATE Books SET name='$name' WHERE ID=$id";
    mysqli_query($con,$sql);
} 
if(strlen($email) > 0){
    $sql="UPDATE Books SET author='$email' WHERE ID=$id";
    mysqli_query($con,$sql);
} 
if(strlen($m) > 0){
    $sql="UPDATE Books SET catagory='$m' WHERE ID=$id";
    mysqli_query($con,$sql);
} 
if(strlen($quantity) > 0){
    $sql="UPDATE Books SET Quantity='$quantity' WHERE ID=$id";
    mysqli_query($con,$sql);
} 
if(strlen($link) > 0){
    $sql="UPDATE Books SET link='$link' WHERE ID=$id";
    mysqli_query($con,$sql);
} 

echo "Book information updated Successfully!";




?>