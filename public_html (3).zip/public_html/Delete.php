<?php

$id=$_GET['i'];


$con=mysqli_connect("localhost","nurmoham_mad","@Nurmohammad1145","nurmoham_mad");

if(strlen($id) == 0){
   echo "You didn't enter any id";
    
} 
else {
    $sql="DELETE FROM Books WHERE ID=$id";
    mysqli_query($con,$sql);
    echo "Deleted Successfully";
 
}





?>