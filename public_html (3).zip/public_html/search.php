<?php
header('Content-Type: application/json');
$id = "";
$name = "";
$email = "";
$mobile = "";


if (isset($_GET['i']) && strlen($_GET['i']) > 0) {
    $id = $_GET['i'];
}
if (isset($_GET['n']) && strlen($_GET['n']) > 0) {
    $name = $_GET['n'];
}
if (isset($_GET['e']) && strlen($_GET['e']) > 0) {
    $email = $_GET['e'];
}
if (isset($_GET['m']) && strlen($_GET['m']) > 0) {
    $mobile = $_GET['m'];
}

$con = mysqli_connect("localhost", "nurmoham_mad", "@Nurmohammad1145", "nurmoham_mad");

if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}

// Build the query safely
$sql = "SELECT * FROM `Books` WHERE 
    ID LIKE '%$id%' AND 
    name LIKE '%$name%' AND 
    author LIKE '%$email%' AND 
    catagory LIKE '%$mobile%'";

$result = mysqli_query($con, $sql);

$data = array();

if ($result) {
    foreach ($result as $row) {
        $userinfo['id'] = $row['ID'];
        $userinfo['name'] = $row['name'];
        $userinfo['email'] = $row['author'];
        $userinfo['mobile'] = $row['catagory'];
        $userinfo['link'] = $row['link'];
        $userinfo['Quantity'] = $row['Quantity'];

        array_push($data, $userinfo);
    }
} else {
    echo "Error in SQL: " . mysqli_error($con);
    exit;
}

echo json_encode($data);
?>
