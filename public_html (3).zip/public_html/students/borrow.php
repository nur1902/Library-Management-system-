<?php

$Sname = $_GET['sn'];
$Sid = $_GET['sid'];
$Bname = $_GET['n'];
$Bid = $_GET['i'];
$date=$_GET['d'];
//$quantity= $_GET['q'];

if (isset($_GET['q'])) {
    
    $quantity = (int)$_GET['q'];
    
}





$con = mysqli_connect("localhost", "nurmoham_mad", "@Nurmohammad1145", "nurmoham_mad");

if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}

$sql = "INSERT INTO `Borrowed` (student_id,student_name,book_ID, book_name) VALUES ('$Sid', '$Sname', '$Bid', '$Bname')";
$sql2="INSERT INTO `Borrow` (B_id, B_name, s_id, s_name, date)
VALUES ('$Bid', '$Bname', '$Sid', '$Sname', '$date')";



if($quantity>0){
    if (mysqli_query($con, $sql)) {
    echo "Borrowed Successfully!";
    //$quantity=$quantity-1;
    $sql1 = "CREATE TRIGGER 
    decrease_quantity
AFTER INSERT ON Borrowed
FOR EACH ROW
BEGIN
    UPDATE Books
    SET quantity = quantity - 1
    WHERE ID = NEW.book_ID;
END;
";
    mysqli_query($con,$sql1);
    mysqli_query($con,$sql2);
    
    
}

 else {
    echo "Error: " . mysqli_error($con);
}
}
else {
    echo " No More this books in library";
}




?>