<?php
    header('Content-Type: application/json; charset=utf-8');
 $con=mysqli_connect("localhost","nurmoham_mad","@Nurmohammad1145","nurmoham_mad");
   
    $pars="SELECT 
    s.student_id,
    s.student_name,
    b.ID AS book_ID,
    b.name AS book_name,
    b.author,
    b.catagory
FROM Borrowed s
INNER JOIN Books b
    ON s.book_id = b.ID;";
    $result=mysqli_query($con,$pars);
    $data=array();
    
   
    foreach($result as $row){
          
    $userinfo['student_id']=$row['student_id'];
    $userinfo['student_name']=$row['student_name'];
    $userinfo['book_id']=$row['book_ID'];
    $userinfo['book_name']=$row['book_name'];
    

    array_push($data, $userinfo);
    
    }

    echo json_encode($data);
    
    
    
 
?>