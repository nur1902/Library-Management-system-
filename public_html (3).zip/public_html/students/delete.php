<?php

$student_id=$_GET['i'];

$book_id=$_GET['bi'];
$student_name=$_GET['sn'];
$book_name=$_GET['bn'];
$date=$_GET['d'];

$con=mysqli_connect("localhost","nurmoham_mad","@Nurmohammad1145","nurmoham_mad");

 
    $sql="DELETE FROM Borrowed WHERE student_id=$student_id AND book_ID=$book_id";
    $sql1="INSERT INTO `Returns` (B_id, B_name, s_id, s_name, date)
VALUES ('$book_id', '$book_name', '$student_id', '$student_name', '$date')";

    if(mysqli_query($con,$sql)){
        mysqli_query($con,$sql1);
   
     echo "Deleted Successfully";
    }
    else echo "Cannot Delete";

    
    $sql1="SELECT Quantity FROM Books WHERE ID =$book_id";
    $result = mysqli_query($con, $sql1);






   
 

    



?>