<?php
    header('Content-Type: application/json; charset=utf-8');
 $con=mysqli_connect("localhost","nurmoham_mad","@Nurmohammad1145","nurmoham_mad");
   
    $pars="SELECT * FROM Students";
    $result=mysqli_query($con,$pars);
    $data=array();
    
   
    foreach($result as $row){
          
    $userinfo['id']=$row['S_id'];
    $userinfo['name']=$row['S_name'];
   

    array_push($data, $userinfo);
    
    }

    echo json_encode($data);
    
    
    
    
 
?>