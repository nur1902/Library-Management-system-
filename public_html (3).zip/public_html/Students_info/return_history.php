<?php
$sid = $_GET['si'];
$sname = $_GET['sn'];
$bid = $_GET['bi'];  
$bname = $_GET['bn'];
$date=$_GET['d'];




$con = mysqli_connect("localhost", "nurmoham_mad", "@Nurmohammad1145", "nurmoham_mad");

if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}

$sql = "INSERT INTO `Returns` (B_id, B_name, s_id, s_name, date)
VALUES ('$Bid', '$Bname', '$Sid', '$Sname', '$date')";


if (mysqli_query($con, $sql)) {
    echo "Connected and inserted successfully.";
} else {
    echo "Error: " . mysqli_error($con);
}



?>
