<?php
    header('Content-Type: application/json; charset=utf-8');
 $con=mysqli_connect("localhost","nurmoham_mad","@Nurmohammad1145","nurmoham_mad");
   
    $pars="SELECT * FROM Borrow;";
    $result=mysqli_query($con,$pars);
    $data=array();
    
   
    foreach($result as $row){
          
    $userinfo['student_id']=$row['S_id'];
    $userinfo['student_name']=$row['S_name'];
    $userinfo['book_id']=$row['B_id'];
    $userinfo['book_name']=$row['B_name'];
    $userinfo['date']=$row['date'];
    

    array_push($data, $userinfo);
    
    }

    echo json_encode($data);
    
    
    
 
?>